#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 22:56:08 2021

operator.py

@author: nlourie
"""


import os
import numpy as np
import sys
from datetime import datetime
from PyQt5 import QtCore
import time
import json
import logging
import threading
import astropy.time
import astropy.coordinates
import astropy.units as u
# add the wsp directory to the PATH
wsp_path = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(1, wsp_path)

from utils import utils
from schedule import schedule
from schedule import ObsWriter


class TimerThread(QtCore.QThread):
    '''
    This is a thread that just counts up the timeout and then emits a 
    timeout signal. It will be connected to the worker thread so that it can
    run a separate thread that times each worker thread's execution
    '''
    timerTimeout = QtCore.pyqtSignal()
    
    def __init__(self, timeout, *args, **kwargs):
        super(TimerThread, self).__init__()
        print('created a timer thread')
        # Set up the timeout. Convert seconds to ms
        self.timeout = timeout*1000.0
    
        
    def run(self):
        def printTimeoutMessage():
            print(f'timer thread: timeout happened')
        print(f'running timer in thread {threading.get_ident()}')
        # run a single shot QTimer that emits the timerTimeout signal when complete
        self.timer= QtCore.QTimer()
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(printTimeoutMessage)
        self.timer.timeout.connect(self.timerTimeout.emit)
        self.timer.start(self.timeout)
        self.exec_() 

class RoboOperatorThread(QtCore.QThread):
    """
    A dedicated thread to handle all the robotic operations!
    
    This is basically a thread to handle all the commands which get sent in 
    robotic mode
    """
    
    # this signal is connected to the RoboOperator's start_robo method
    restartRoboSignal = QtCore.pyqtSignal()
    
    # this signal is typically emitted by wintercmd, and is connected to the RoboOperators change_schedule method
    changeSchedule = QtCore.pyqtSignal(object)
    
    def __init__(self, base_directory, config, mode, state, wintercmd, logger, alertHandler, schedule, telescope, dome, chiller, ephem):
        super(QtCore.QThread, self).__init__()
        
        self.base_directory = base_directory
        self.config = config
        self.mode = mode
        self.state = state
        self.wintercmd = wintercmd
        self.wintercmd.roboThread = self
        self.schedule = schedule
        self.telescope = telescope
        self.dome = dome
        self.chiller = chiller
        self.logger = logger
        self.alertHandler = alertHandler
        self.ephem = ephem
        
    
    def run(self):           
        self.robo = RoboOperator(base_directory = self.base_directory, 
                                     config = self.config, 
                                     mode = self.mode,
                                     state = self.state, 
                                     wintercmd = self.wintercmd,
                                     logger = self.logger,
                                     alertHandler = self.alertHandler,
                                     schedule = self.schedule,
                                     telescope = self.telescope, 
                                     dome = self.dome, 
                                     chiller = self.chiller, 
                                     ephem = self.ephem
                                     )
        
        # Put all the signal/slot connections here:
        ## if we get a signal to start the robotic operator, start it!
        self.restartRoboSignal.connect(self.robo.restart_robo)
        ## change schedule
        self.changeSchedule.connect(self.robo.change_schedule)
        # Start the event loop
        self.exec_()

class roboError(object):
    """
    This is a class used to broadcast errors as pyqtSignals.
    The idea is that this will be caught elsewhere by the system monitor
    which can try to reboot or otherwise handle these errors.
    
    cmd:    the command that the roboOperator was trying to execute, eg 'dome_home'
    system: the system that the command involves, eg 'chiller'. this is used for rebooting
    err:    whatever error message goes along with this error
    """
    
    def __init__(self, context, cmd, system, msg):
        self.context = context
        self.cmd = cmd
        self.system = system
        self.msg = msg
        
class RoboOperator(QtCore.QObject):

    hardware_error = QtCore.pyqtSignal(object)  
    
    startRoboSignal = QtCore.pyqtSignal()
    stopRoboSignal = QtCore.pyqtSignal()
    
    

    

    def __init__(self, base_directory, config, mode, state, wintercmd, logger, alertHandler, schedule, telescope, dome, chiller, ephem):
        super(RoboOperator, self).__init__()
        
        self.base_directory = base_directory
        self.config = config
        self.mode = mode
        self.state = state
        self.wintercmd = wintercmd
        # assign self to wintercmd so that wintercmd has access to the signals
        self.wintercmd.roboOperator = self
        self.alertHandler = alertHandler
        # set up the hardware systems
        self.telescope = telescope
        self.dome = dome
        self.chiller = chiller
        self.logger = logger
        self.alertHandler = alertHandler
        self.ephem = ephem
        self.schedule = schedule
        
        # keep track of the last command executed so it can be broadcast as an error if needed
        self.lastcmd = None
        
        ### OBSERVING FLAGS ###
        # set attribute to indicate if robo operator is running (
        ## this flag is used to pause the schedule execution if we want to. 
        ## ie we want to stop the schedule even though it's okay to observe
        self.running = True
        
        # set an attribute to indicate if we are okay to observe
        ## ie, if startup is complete, the calibration is complete, and the weather/dome is okay
        self.ok_to_observe = False
    
        
        ### SET UP THE WRITER ###
        # init the database writer
        writerpath = self.config['obslog_directory'] + '/' + self.config['obslog_database_name']
        #self.writer = ObsWriter.ObsWriter('WINTER_ObsLog', self.base_directory, config = self.config, logger = self.logger) #the ObsWriter initialization
        self.writer = ObsWriter.ObsWriter(writerpath, self.base_directory, config = self.config, logger = self.logger) #the ObsWriter initialization
        # create an empty dict that will hold the data that will get written out to the fits header and the log db
        self.data_to_log = dict()
        
        ### SCHEDULE ATTRIBUTES ###
        # load the dither list
        self.dither_alt, self.dither_az = np.loadtxt(self.schedule.base_directory + '/' + self.config['dither_file'], unpack = True)
        # convert from arcseconds to degrees
        self.dither_alt *= (1/3600.0)
        self.dither_az  *= (1/3600.0)
        
        # create exposure timer to wait for exposure to finish
        self.waiting_for_exposure = False
        self.exptimer = QtCore.QTimer()
        self.exptimer.setSingleShot(True)
        # if there's too many things i think they may not all get triggered?
        #self.exptimer.timeout.connect(self.log_timer_finished)
        self.exptimer.timeout.connect(self.log_observation_and_gotoNext)
        #self.exptimer.timeout.connect(self.rotator_stop_and_reset)

        
        ### CONNECT SIGNALS AND SLOTS ###
        self.startRoboSignal.connect(self.restart_robo)
        self.stopRoboSignal.connect(self.stop)
        #TODO: is this right (above)? NPL 4-30-21
        
        self.hardware_error.connect(self.broadcast_hardware_error)
        
        self.telescope.signals.wrapWarning.connect(self.handle_wrap_warning)
        # change schedule. for now commenting out bc i think its handled in the robo Thread def
        #self.changeSchedule.connect(self.change_schedule)
        
        ## overrides
        # override the dome.ok_to_open flag
        self.dome_override = False
        # override the sun altitude flag
        self.sun_override = True
        
        # some variables that hold the state of the sequences
        self.startup_complete = False
        self.calibration_complete = False
        
        ### SET UP THE SCHEDULE ###
        self.lastSeen = -1
        ## in robotic mode, the schedule file is the nightly schedule
        if self.mode == 'r':
            self.schedulefile_name = 'nightly'
        ## in manual mode, the schedule file is set to None
        else:
            self.schedulefile_name = None
            
        # set up the schedule
        ## after this point we should have something in self.schedule.currentObs
        self.setup_schedule()
        
        
        
        # start up the robotic observing!
        if self.mode == 'r':
            # start the robo?
            self.restart_robo()        # make a timer that will control the cadence of checking the conditions
            
        
    def broadcast_hardware_error(self, error):
        msg = f':redsiren: *{error.system.upper()} ERROR* ocurred when attempting command: *_{error.cmd}_*, {error.msg}'
        group = 'sudo'
        self.alertHandler.slack_log(msg, group = group)
        
        # turn off tracking
        self.rotator_stop_and_reset()
        
    def announce(self, msg):
        self.logger.info(f'robo: {msg}')
        self.alertHandler.slack_log(msg, group = None)
    
    def rotator_stop_and_reset(self):
        # turn off tracking
        self.doTry('mount_tracking_off')
        self.doTry('rotator_home')
        
    def handle_wrap_warning(self, angle):
        
        # create a notification
        msg = f'*WRAP WARNING!!* rotator angle {angle} outside allowed range [{self.config["telescope"]["rotator_min_degs"]},{self.config["telescope"]["rotator_max_degs"]}])'       
        context = ''
        system = 'rotator'
        cmd = self.lastcmd
        err = roboError(context, cmd, system, msg)
        # directly broadcast the error rather than use an event to keep it all within this event
        self.broadcast_hardware_error(err)
        
        # STOP THE ROTATOR
        self.rotator_stop_and_reset()
        
        # got to the next observation
        self.gotoNext()
    
    def restart_robo(self):
        # run through the whole routine. if something isn't ready, then it waits a short period and restarts
        while True:
            # EXECUTE THE FULL ROBOTIC SEQUENCE
            # return statements will exit and stop the robotic sequence
            # every time there's a return there needs to be an error emitted
            if not self.startup_complete:
                # Do the startup routine
                self.do_startup()
                # If that didn't work, then return
                if not self.startup_complete:
                    return
                    #break
            # if we're done with the startup, continue
            if not self.calibration_complete:
                # do the calibration:
                self.do_calibration()
                # If that didn't work, then return
                if not self.calibration_complete:
                    return
                    #break
            
            self.check_ok_to_observe()
            if self.ok_to_observe:
                break
            else:
                time.sleep(0.5)
            
        # we escaped the loop!
        # if it's okay to observe, then do the first observation!
        self.do_currentObs()
        return
        
    def check_ok_to_observe(self, logcheck = False):
        """
        check if it's okay to observe/open the dome
        
        
        # logcheck flag indicates whether the result of the check should be written to the log
            we want the result logged if we're checking from within the do_observing loop,
            but if we're just loopin through restart_robo we can safely ignore the constant logging'
        """
        
        # if the sun is below the horizon, or if the sun_override is active, then we want to open the dome
        if self.ephem.sun_below_horizon or self.sun_override:
            
            # make a note of why we want to open the dome
            if self.ephem.sun_below_horizon:
                #self.logger.info(f'robo: the sun is below the horizon, I want to open the dome.')
                pass
            elif self.sun_override:
                if logcheck:
                    self.logger.warning(f"robo: the SUN IS ABOVE THE HORIZON, but sun_override is active so I want to open the dome")
            else:
                # shouldn't ever be here
                if logcheck:
                    self.logger.warning(f"robo: I shouldn't ever be here. something is wrong with sun handling")
                self.ok_to_observe = False
                #return
                #break
            
            # if we can open up the dome, then do it!
            if (self.dome.ok_to_open or self.dome_override):
                
                # make a note of why we're going ahead with opening the dome
                if self.dome.ok_to_open:
                    #self.logger.info(f'robo: the dome says it is okay to open.')# sending open command.')
                    pass
                elif self.dome_override:
                    if logcheck:
                        self.logger.warning(f"robo: the DOME IS NOT OKAY TO OPEN, but dome_override is active so I'm sending open command")
                else:
                    # shouldn't ever be here
                    self.logger.warning(f"robo: I shouldn't ever be here. something is wrong with dome handling")
                    self.ok_to_observe = False
                    #return
                    #break
                
               
                
                # Check if the dome is open:
                if self.dome.Shutter_Status == 'OPEN':
                    if logcheck:
                        self.logger.info(f'robo: okay to observe check passed')
                    
                    #####
                    # We're good to observe
                    self.ok_to_observe = True
                    #break
                    #####
                
                else:
                    # dome is closed.
                    """
                    #TODO: this is weird. This function should either be just a status poll
                    that is executed regularly, or it should be only run rarely.
                    having the open command in here makes it kind of a weird in-between
                    
                    """
                    msg = f'robo: shutter is closed. attempting to open...'
                    self.announce(msg)
                     # SEND THE DOME OPEN COMMAND
                    self.doTry('dome_open', context = 'startup', system = 'dome')
                    self.logger.info(f'robo: error opening dome.')
                    self.ok_to_observe = False
                    
            else:
                # there is an issue with the dome
                
                self.ok_to_observe = False
                    
            
        else:
            # the sun is up
            self.ok_to_observe = False
        
        
            
            
    
    def setup_schedule(self):
        
        if self.schedulefile_name is None:
            # NPL 9-21-20: put this in for now so that the while loop in run wouldn't go if the schedule is None
            self.schedule.currentObs = None

        else:
            #print(f'scheduleExecutor: loading schedule file [{self.schedulefile_name}]')
            # code that sets up the connections to the databases
            self.getSchedule(self.schedulefile_name)
            self.writer.setUpDatabase()
    
        
    
    def getSchedule(self, schedulefile_name):
        self.schedule.loadSchedule(schedulefile_name, self.lastSeen+1)

    def interrupt(self):
        self.schedule.currentObs = None

    def stop(self):
        self.running = False
        #TODO: Anything else that needs to happen before stopping the thread

    def change_schedule(self, schedulefile_name):
        """
        This function handles the initialization needed to start observing a
        new schedule. It is called when the changeSchedule signal is caught,
        as well as when the thread is first initialized.
        """

        print(f'scheduleExecutor: setting up new schedule from file >> {schedulefile_name}')

        if self.running:
            self.stop()

        self.schedulefile_name = schedulefile_name
        
        #NPL 4-29-21:
        self.setup_schedule()

    def get_data_to_log(self):
        data = {}
        # First, handle all the keys from self.schedule.currentObs.
        # THESE ARE SPECIAL KEYS WHICH ARE REQUIRED FOR THE SCHEDULER TO WORK PROPERLY
        
        keys_with_actual_vals = ["dist2Moon", "expMJD", "visitExpTime", "azimuth", "altitude"]
        
        for key in self.schedule.currentObs:
            # Some entries need the scheduled AND actuals recorded
                    
            if key in keys_with_actual_vals:
                data.update({f'{key}_scheduled': self.schedule.currentObs[key]})
            else:
                data.update({key: self.schedule.currentObs[key]})
        
        # now update the keys with actual vals with their actual vals
        data.update({'dist2Moon'    : self.getDist2Moon(),
                     'expMJD'       : self.getMJD(),
                     'visitExpTime' : self.waittime, 
                     'altitude'     : self.state['mount_az_deg'], 
                     'azimuth'      : self.state['mount_alt_deg']
                     })
        # now step through the Observation entries in the dataconfig.json and grab them from state
        
        for key in self.writer.dbStructure['Observation']:
            # make sure we don't overwrite an entry from the currentObs or the keys_with_actual_vals
            ## ie, make sure it's a key that's NOT already in data
            if (key not in data.keys()):
                # if the key is in state, then update data
                if key in self.state.keys():
                    data.update({key : self.state[key]})
                else:
                    pass
            else:
                pass
        return data
    
    def getMJD(self):
        now_utc = datetime.utcnow()
        T = astropy.time.Time(now_utc, format = 'datetime')
        mjd = T.mjd
        return mjd
        
    
    def getDist2Moon(self):
        delta_alt = self.state['mount_alt_deg'] - self.ephem.moonalt
        delta_az = self.state['mount_az_deg'] - self.ephem.moonaz
        dist2Moon = (delta_alt**2 + delta_az**2)**0.5
        return dist2Moon
    
    def log(self, msg, level = logging.INFO):
        if self.logger is None:
                print(msg)
        else:
            self.logger.log(level = level, msg = msg)
    
    
    def doTry(self, cmd, context = '', system = ''):
        """
        This does the command by calling wintercmd.parse.
        The command should be written the same way it would be from the command line
        The system is specified so that alert signals can be broadcast out to various 
        
        This will emit an error signal if the command doesn't work, but it will not kill program
        """
        

        self.lastcmd = cmd
        try:
            self.wintercmd.parse(cmd)
        
        except Exception as e:
            msg = f'roboOperator: could not execute function {cmd} due to {e.__class__.__name__}, {e}'
            self.log(msg)
            err = roboError(context, cmd, system, msg)
            self.hardware_error.emit(err)
        
    
    def do(self, cmd):
        """
        This does the command by calling wintercmd.parse.
        The command should be written the same way it would be from the command line
        The system is specified so that alert signals can be broadcast out to various 
        """
        self.lastcmd = cmd
        self.wintercmd.parse(cmd)

    def wait_for_dome_clearance(self):
        """
        This should just run a QTimer which waits until one of several 
        things happens:
            1. the dome is okay to open. then it will restart_robo()
            2. the sun will come up and we'll miss our window. in this case,
               initiate shutdown
        """
        pass
    
    def do_startup(self):
        # this is for passing to errors
        context = 'do_startup'
        
        ### DOME SET UP ###
        system = 'dome'
        msg = 'starting dome startup...'
        self.announce(msg)

        try:
            # take control of dome        
            self.do('dome_takecontrol')
    
            # home the dome
            self.do('dome_home')
            
            # signal we're complete
            msg = 'dome startup complete'
            self.logger.info(f'robo: {msg}')
            self.alertHandler.slack_log(f':greentick: {msg}')
        except Exception as e:
            msg = f'roboOperator: could not set up {system} due to {e.__class__.__name__}, {e}'
            self.log(msg)
            err = roboError(context, self.lastcmd, system, msg)
            self.hardware_error.emit(err)
            return
        
        
        ### MOUNT SETUP ###
        system = 'telescope'
        msg = 'starting telescope startup...'
        self.announce(msg)
        try:
            # connect the telescope
            self.do('mount_startup')
            
            # turn on the rotator
            self.do('rotator_enable')
            
            # NO DON'T DO THIS turn on tracking
            #self.do('mount_tracking_on')
            
            # TURN ON WRAP CHECK 
            self.do('rotator_wrap_check_enable')
            
            
        
        except Exception as e:
            msg = f'roboOperator: could not set up {system} due to {e.__class__.__name__}, {e}'
            self.log(msg)
            self.alertHandler.slack_log(f'*ERROR:* {msg}', group = None)
            err = roboError(context, self.lastcmd, system, msg)
            self.hardware_error.emit(err)
            return
        self.announce(':greentick: telescope startup complete!')
        
        # turn on 
        
        # if we made it all the way to the bottom, say the startup is complete!
        self.startup_complete = True
            
        self.announce(':greentick: startup complete!')
        
    def do_calibration(self):
        
        context = 'do_calibration'
        
        self.logger.info('robo: doing calibration routine. for now this does nothing.')
        ### Take darks ###
        # Nothing here yet
        
        
        self.calibration_complete = True
    
    def do_currentObs(self):
        """
        do the observation of whatever is the current observation in self.schedule.currentObs
        
        then create the dictionary that will be used to log to the database, and create the fits header
            --> this uses self.writer.separate_data_dict
        then command the camerat to take an image and send it the fits header information
        
        then it starts the image wait QTimer, and returns
            --> the QTimer.finished signal is connected self.log_observation_and_gotoNext() 
                which send the data from the observation to the log database, goes to the next line in the schedule,
                and then calls do_currentObs again
                BOTH do_currentObs and log_observation_and_gotoNext will only execute if self.running == True
        
        the WHOLE POINT of this event-based approach rather than using an infinite loop
        is to keep everything responsive, so that we can break into the loop if necessary.
        Using an infinite loop and a long wait is ~bad~ because if the thread is blocked
        it will miss outside signals.
        
        Things to handle:
            - how is the observing loop interuppted if there is something like a weather closure?
            - how is the observing loop restarted after a weather closure ends?
            
            --> possible solution: 
                    create a signal which will:
                        1. set running to False to prevent any futher logging
                        2. kill the exposure QTimer
                        3. emit a restartRobo signal so it gets kicked back to the top of the tree
        
        """
        self.check_ok_to_observe(logcheck = True)
        if self.running & self.ok_to_observe:
            
            # grab some fields from the currentObs
            self.lastSeen = self.schedule.currentObs['obsHistID']
            self.alt_scheduled = float(self.schedule.currentObs['altitude'])
            self.az_scheduled = float(self.schedule.currentObs['azimuth'])
            msg = f'executing observation of obsHistID = {self.lastSeen} at (alt, az) = ({self.alt_scheduled:0.2f}, {self.az_scheduled:0.2f})'
            self.announce(msg)
            
            # 1: point the telescope
            #TODO: change this to RA/DEC pointing instead of AZ/EL
            context = 'do_currentObs'
            system = 'telescope'
            try:
                # point the rotator to the home position
                self.do(f'rotator_home')
                
                # turn tracking back on
                self.do(f'rotator_enable')
                # don't turn the tracking on it will drift off. just leave the rotator enabled and tracking off and then do a goto RA/DEC
                #self.do(f'mount_tracking_on')
                
                # TURN ON WRAP CHECK 
                self.do('rotator_wrap_check_enable')
                
                # check if alt and az are in allowed ranges
                in_view = (self.alt_scheduled >= self.config['telescope']['min_alt']) & (self.alt_scheduled <= self.config['telescope']['max_alt'])
                if in_view:
                    pass
                else:
                    msg = f'>> target not within view! skipping...'
                    self.log(msg)
                    self.alertHandler.slack_log(msg, group = 'sudo')
                    self.gotoNext()
                    return
                
                # Launder the alt and az scheduled to RA/DEC
                self.lastcmd = 'convert_alt-az_to_ra-dec'
                #TODO: remove this! This is just a patch so that we can observe the schedule during the day
                az_angle = astropy.coordinates.Angle(self.az_scheduled * u.deg)
                alt_angle = astropy.coordinates.Angle(self.alt_scheduled * u.deg)
                obstime_utc = astropy.time.Time(datetime.utcnow(), format = 'datetime')
                
                
                altaz_coords = astropy.coordinates.SkyCoord(alt = alt_angle, az = az_angle,
                                                            obstime = obstime_utc,
                                                            location = self.ephem.site,
                                                            frame = 'altaz')
                j2000_coords = altaz_coords.transform_to('icrs')
                j2000_ra_hours = j2000_coords.ra.hour
                j2000_dec_deg = j2000_coords.dec.deg
                
                
                # slew the telscope
                #self.do(f'mount_goto_alt_az {self.alt_scheduled} {self.az_scheduled}')
                self.do(f'mount_goto_ra_dec_j2000 {j2000_ra_hours} {j2000_dec_deg}')
                
            except Exception as e:
                msg = f'roboOperator: could not set up {system} due to {e.__class__.__name__}, {e}'
                self.log(msg)
                err = roboError(context, self.lastcmd, system, msg)
                self.hardware_error.emit(err)
                return
            
            system = 'dome'
            try:
                self.do(f'dome_goto {self.az_scheduled}')
            except Exception as e:
                msg = f'roboOperator: could not set up {system} due to {e.__class__.__name__}, {e}'
                self.log(msg)
                err = roboError(context, self.lastcmd, system, msg)
                self.hardware_error.emit(err)
                return
            # 2: create the log dictionary & FITS header. save log dict to self.lastObs_record
            # 3: trigger image acquisition
            # 4: start exposure timer
            self.logger.info('robo: starting timer to wait for exposure to finish')
            self.waittime = float(self.schedule.currentObs['visitExpTime'])#/len(self.dither_alt)
            self.waittime_padding = 2.0 # pad the waittime a few seconds just to be sure it's done
            self.waiting_for_exposure = True
            self.exptimer.start((self.waittime + self.waittime_padding)*1000.0) # start the timer with waittime in ms as a timeout
            # 5: exit
            
            
            
        else:
            # if it's not okay to observe, then restart the robo loop to wait for conditions to change
            self.restart_robo()
    def gotoNext(self): 
        #TODO: NPL 4-30-21 not totally sure about this tree. needs testing
        self.check_ok_to_observe(logcheck = True)
        if not self.ok_to_observe:
            # if it's not okay to observe, then restart the robo loop to wait for conditions to change
            self.restart_robo()
            return
            
        if self.schedule.currentObs is not None and self.running:
            """self.logger.info('robo: logging observation')
            
            
            if self.state["ok_to_observe"]:
                    image_filename = str(self.lastSeen)+'.FITS'
                    image_filepath = os.path.join(self.writer.base_directory, self.config['image_directory'], image_filename) 
                    # self.telescope_mount.virtualcamera_take_image_and_save(imagename)
                    header_data = self.get_data_to_log()
                    # self.state.update(currentData)
                    # data_to_write = {**self.state}
                    #data_to_write = {**self.state, **header_data} ## can add other dictionaries here
                    #self.writer.log_observation(data_to_write, imagename)
                    self.writer.log_observation(header_data, image_filepath)"""
            
            # get the next observation
            self.announce('getting next observation from schedule database')
            self.schedule.gotoNextObs()
            
            # do the next observation and continue the cycle
            self.do_currentObs()
            
        else:  
            if self.schedule.currentObs is None:
                self.logger.info('robo: in log and goto next, but either there is no observation to log.')
            elif self.running == False:
                self.logger.info("robo: in log and goto next, but I caught a stop signal so I won't do anything")
            
            if not self.schedulefile_name is None:
                self.logger.info('robo: no more observations to execute. shutting down connection to schedule and logging databases')
                ## TODO: Code to close connections to the databases.
                self.schedule.closeConnection()
                self.writer.closeConnection()
                
                
    def log_observation_and_gotoNext(self):
        self.logger.info('robo: image timer finished, logging observation and then going to the next one')
        # first thing's first, stop and reset the rotator
        self.rotator_stop_and_reset()
        
        #TODO: NPL 4-30-21 not totally sure about this tree. needs testing
        self.check_ok_to_observe(logcheck = True)
        if not self.ok_to_observe:
            # if it's not okay to observe, then restart the robo loop to wait for conditions to change
            self.restart_robo()
            return
            
        if self.schedule.currentObs is not None and self.running:
            self.logger.info('robo: logging observation')
            
            
            if self.state["ok_to_observe"]:
                    image_filename = str(self.lastSeen)+'.FITS'
                    image_filepath = os.path.join(self.writer.base_directory, self.config['image_directory'], image_filename) 
                    # self.telescope_mount.virtualcamera_take_image_and_save(imagename)
                    header_data = self.get_data_to_log()
                    # self.state.update(currentData)
                    # data_to_write = {**self.state}
                    #data_to_write = {**self.state, **header_data} ## can add other dictionaries here
                    #self.writer.log_observation(data_to_write, imagename)
                    self.writer.log_observation(header_data, image_filepath)
            
            # get the next observation
            self.logger.info('robo: getting next observation from schedule database')
            self.schedule.gotoNextObs()
            
            # do the next observation and continue the cycle
            self.do_currentObs()
            
        else:  
            if self.schedule.currentObs is None:
                self.logger.info('robo: in log and goto next, but either there is no observation to log.')
            elif self.running == False:
                self.logger.info("robo: in log and goto next, but I caught a stop signal so I won't do anything")
            
            if not self.schedulefile_name is None:
                self.logger.info('robo: no more observations to execute. shutting down connection to schedule and logging databases')
                ## TODO: Code to close connections to the databases.
                self.schedule.closeConnection()
                self.writer.closeConnection()
    
    def log_timer_finished(self):
        self.logger.info('robo: exposure timer finished.')
        self.waiting_for_exposure = False
        
    def old_do_observing(self):
        '''
        This function must contain all of the database manipulation code to remain threadsafe and prevent
        exceptions from being raised during operation
        '''
        self.running = True
 

        while self.schedule.currentObs is not None and self.running:
            #print(f'scheduleExecutor: in the observing loop!')
            self.lastSeen = self.schedule.currentObs['obsHistID']
            self.current_field_alt = float(self.schedule.currentObs['altitude'])
            self.current_field_az = float(self.schedule.currentObs['azimuth'])

            for i in range(len(self.dither_alt)):
                # step through the prescribed dither sequence
                dither_alt = self.dither_alt[i]
                dither_az = self.dither_az[i]
                print(f'Dither Offset (alt, az) = ({dither_alt}, {dither_az})')
                self.alt_scheduled = self.current_field_alt + dither_alt
                self.az_scheduled = self.current_field_az + dither_az

                #self.newcmd.emit(f'mount_goto_alt_az {self.currentALT} {self.currentAZ}')
                if self.state["ok_to_observe"]:
                    print(f'Observing Dither Offset (alt, az) = ({dither_alt}, {dither_az})')
                    self.telescope.mount_goto_alt_az(alt_degs = self.alt_scheduled, az_degs = self.az_scheduled)
                    # wait for the telescope to stop moving before returning
                    while self.state['mount_is_slewing']:
                       time.sleep(self.config['cmd_status_dt'])
                else:
                    print(f'Skipping Dither Offset (alt, az) = ({dither_alt}, {dither_az})')
                self.waittime = int(self.schedule.currentObs['visitTime'])/len(self.dither_alt)
                ##TODO###
                ## Step through current obs dictionairy and update the state dictionary to include it
                ## append planned to the keys in the obs dictionary, to allow us to use the original names to record actual values.
                ## for now we want to add actual waittime, and actual time.
                #####
                self.logger.info(f'robo: Taking a {self.waittime} second exposure...')
                #time.sleep(self.waittime)
                
                if self.state["ok_to_observe"]:
                    imagename = self.writer.base_directory + '/data/testImage' + str(self.lastSeen)+'.FITS'
                    # self.telescope_mount.virtualcamera_take_image_and_save(imagename)
                    currentData = self.get_data_to_log()
                    # self.state.update(currentData)
                    # data_to_write = {**self.state}
                    data_to_write = {**self.state, **currentData} ## can add other dictionaries here
                    self.writer.log_observation(data_to_write, imagename)

            self.schedule.gotoNextObs()

        if not self.schedulefile_name is None:
            ## TODO: Code to close connections to the databases.
            self.schedule.closeConnection()
            self.writer.closeConnection()