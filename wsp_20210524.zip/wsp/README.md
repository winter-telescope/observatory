# WSP: the WINTER Supervisor Program

This is the WINTER Supervisor Program. It is the top-level directory for all telescope control, queuing, imaging, and general robotic operations.

Modules for individual elements are found in their respective folders in this directory, including modules for control of:
	- Telescope
	- Camera
	- Motors
	- Housekeeping
	- Data Logging


