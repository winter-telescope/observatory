#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 13:56:14 2021


weatherd.py

This is part of wsp

# Purpose #

This program reads and parses weather data from the Palomar telemetry server

@author: nlourie
"""



