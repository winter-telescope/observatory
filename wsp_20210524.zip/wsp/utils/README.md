# WSP UTILS

This is a module of useful functions that are or may be used across other modules, ie useful functions for parsing datatypes, building dictionaries, etc.
